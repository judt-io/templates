export default {
  plugins: {
    autoprefixer: {}
  }
}


