import React from 'react'

export default function About() {
    return (
        <div className="space-y-2">
            <h2 className="text-2xl font-semibold">About</h2>
            <p>This is a sample about page rendered with React Router.</p>
        </div>
    )
}


