import React from 'react'

export default function Contact() {
	return (
		<div className="space-y-2">
			<h2 className="text-2xl font-semibold">Contact</h2>
			<p>Get in touch via this sample contact page.</p>
		</div>
	)
}


