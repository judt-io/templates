import { cva as cvaBase } from 'class-variance-authority'

export const cva = cvaBase


